const WXAPI = require('apifm-wxapi')

export default {
  init(page) {
    // page._cancelLogin = this._cancelLogin;
    // page._processLogin = this._processLogin;
  },
  

}